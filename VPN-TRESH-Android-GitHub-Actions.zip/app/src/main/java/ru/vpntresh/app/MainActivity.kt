package ru.vpntresh.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B1118)
private val Panel = Color(0xFF151F2B)
private val Neon = Color(0xFF66F2B2)
private val Muted = Color(0xFFA8B5C4)
private val White = Color(0xFFF4F7FA)

private data class Country(val flag: String, val name: String, val city: String) {
    override fun toString() = "$flag  $name · $city"
}

private val countries = listOf(
    Country("🇩🇪", "Германия", "Франкфурт"),
    Country("🇳🇱", "Нидерланды", "Амстердам"),
    Country("🇺🇸", "США", "Нью-Йорк"),
    Country("🇫🇷", "Франция", "Париж"),
    Country("🇸🇬", "Сингапур", "Сингапур")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TreshApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TreshApp() {
    var selectedCountry by remember { mutableStateOf(countries.first()) }
    var showCountries by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var demoConnected by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon,
            onPrimary = Bg,
            background = Bg,
            surface = Panel,
            onSurface = White
        )
    ) {
        Scaffold(containerColor = Bg) { padding ->
            if (showCountries) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)
                ) {
                    Text("Выбор страны", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = White)
                    Spacer(Modifier.height(8.dp))
                    Text("Выберите локацию для будущего подключения", color = Muted)
                    Spacer(Modifier.height(20.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(countries) { country ->
                            Surface(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    selectedCountry = country
                                    showCountries = false
                                },
                                color = Panel,
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(country.flag, fontSize = 26.sp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(country.name, color = White, fontWeight = FontWeight.SemiBold)
                                        Text(country.city, color = Muted, fontSize = 13.sp)
                                    }
                                    if (selectedCountry == country) {
                                        Icon(Icons.Default.CheckCircle, null, tint = Neon)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { showCountries = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Назад")
                    }
                }
            } else if (showProfile) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)
                ) {
                    Text("Личный кабинет", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = White)
                    Spacer(Modifier.height(24.dp))
                    Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Person, null, tint = Neon, modifier = Modifier.size(54.dp))
                            Text("Гость", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Бесплатный тестовый режим", color = Muted)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Подписка", color = White, fontWeight = FontWeight.Bold)
                    Text("Premium и оплата будут подключены на следующем этапе.", color = Muted)
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { showProfile = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("На главную")
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(22.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, null, tint = Neon, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("VPN-ТРЭШ!", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { showProfile = true }) {
                            Icon(Icons.Default.Person, contentDescription = "Профиль", tint = Muted)
                        }
                    }
                    Spacer(Modifier.height(36.dp))
                    Text(
                        if (demoConnected) "ДЕМО-РЕЖИМ" else "ТВОЙ ИНТЕРНЕТ — ТВОИ ПРАВИЛА",
                        color = Muted, fontSize = 12.sp, letterSpacing = 1.1.sp
                    )
                    Spacer(Modifier.height(24.dp))
                    Surface(
                        modifier = Modifier.size(176.dp).clickable { demoConnected = !demoConnected },
                        shape = CircleShape,
                        color = Panel,
                        border = androidx.compose.foundation.BorderStroke(2.dp, if (demoConnected) Neon else Color(0xFF2C3B4A))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.PowerSettingsNew,
                                contentDescription = "Демо-переключатель",
                                tint = Neon,
                                modifier = Modifier.size(74.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(
                        if (demoConnected) "Демо включено" else "Не подключено",
                        color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("Кнопка пока меняет только экран — VPN не запускается", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(28.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { showCountries = true },
                        color = Panel,
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedCountry.flag, fontSize = 28.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(selectedCountry.name, color = White, fontWeight = FontWeight.Bold)
                                Text("Локация: ${selectedCountry.city}", color = Muted, fontSize = 13.sp)
                            }
                            Icon(Icons.Default.ChevronRight, null, tint = Muted)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        InfoCard("WireGuard", "Не подключён", Icons.Default.Lock, Modifier.weight(1f))
                        InfoCard("Premium", "Скоро", Icons.Default.Star, Modifier.weight(1f))
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationBar(containerColor = Panel) {
                        NavigationBarItem(
                            selected = true,
                            onClick = {},
                            icon = { Icon(Icons.Default.PowerSettingsNew, null) },
                            label = { Text("Главная") }
                        )
                        NavigationBarItem(
                            selected = false,
                            onClick = { showCountries = true },
                            icon = { Icon(Icons.Default.Language, null) },
                            label = { Text("Страны") }
                        )
                        NavigationBarItem(
                            selected = false,
                            onClick = { showProfile = true },
                            icon = { Icon(Icons.Default.Person, null) },
                            label = { Text("Профиль") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = Panel, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = Neon)
            Spacer(Modifier.height(8.dp))
            Text(title, color = White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}
